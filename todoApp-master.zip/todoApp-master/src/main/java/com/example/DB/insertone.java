package com.example.DB;

import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;

public class insertone {
    public static void main(String[] args) {
        MongoClient client = new MongoClient("localhost",27017);
        MongoDatabase database = client.getDatabase("Assignment");
        MongoCollection<Document> collection = database.getCollection("Test");

        Document db = new Document("Name","Srijit").append("Age", "22").append("Gender", "Male");
        collection.insertOne(db);

        System.out.println("Document Inserted Succesfully");
    }
    
}
