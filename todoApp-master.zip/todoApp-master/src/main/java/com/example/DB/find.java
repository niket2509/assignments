package com.example.DB;

import java.util.Iterator;

import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mysql.cj.x.protobuf.MysqlxCrud.Collection;

import org.bson.Document;

public class find {
    public static void main(String[] args) {
        MongoClient client = new MongoClient("localhost",27017);
        MongoDatabase database = client.getDatabase("Assignment");
        MongoCollection<Document> collection = database.getCollection("Test");

        Document doc5 = new Document("Name","Debaditya").append("Age", "18").append("Gender", "Male");
        collection.insertOne(doc5);

        int i=1;

        Iterator it = collection.find().iterator();
        while (it.hasNext()){
            System.out.println(it.next());
            i++;
        }
    }
}
