package com.example.DB;

import java.util.ArrayList;
import java.util.List;

import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;

public class insertmany {
    public static void main(String[] args) {
        String dbname = "Assignment";
        String collname = "Test";
        MongoClient mongoClient = new MongoClient("localhost", 27017);
        MongoDatabase mongoDatabase = mongoClient.getDatabase(dbname);
        MongoCollection<Document> collection = mongoDatabase.getCollection(collname);
        Document doc = new Document("Name", "Kuntal").append("Age", "22").append("Gender", "Male");
        Document doc1 = new Document("Name", "Barsha").append("Age", "21").append("Gender", "Female");
        Document doc2 = new Document("Name", "Ayush").append("Age", "8").append("Gender", "Male");
        Document doc3 = new Document("Name", "Sanju").append("Age", "18").append("Gender", "Male");
        Document doc4 = new Document("Name", "Subhajit").append("Age", "37").append("Gender", "Male");

        List<Document> doclist = new ArrayList<>();
        doclist.add(doc);
        doclist.add(doc1);
        doclist.add(doc2);
        doclist.add(doc3);
        doclist.add(doc4);

        collection.insertMany(doclist);
        System.out.println("Document Inserted Succesfully");
    }
}
