package com.example.DB;

import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mysql.cj.x.protobuf.MysqlxCrud.Collection;

import org.bson.Document;

public class updateone {
    public static void main(String[] args) {
    String dbname = "Assignment";
        String collname = "Test";
        MongoClient mongoClient = new MongoClient("localhost", 27017);
        MongoDatabase mongoDatabase = mongoClient.getDatabase(dbname);
        MongoCollection<Document> collection = mongoDatabase.getCollection(collname);

        Document dbc = new Document("Name","Raj").append("Age", "25").append("Gender", "Male");
        collection.insertOne(dbc);

        collection.updateOne(Filters.eq("Name", "Kuntal"), Updates.set("Name", "Saralya"));
    }
}
