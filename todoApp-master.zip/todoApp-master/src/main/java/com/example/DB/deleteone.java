package com.example.DB;

import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.result.DeleteResult;
import com.mysql.cj.x.protobuf.MysqlxCrud.Delete;

import org.bson.Document;

public class deleteone {
    public static void main(String[] args) {
        String dbname = "Assignment";
        String collname = "Test";
        MongoClient mongoClient = new MongoClient("localhost", 27017);
        MongoDatabase mongoDatabase = mongoClient.getDatabase(dbname);
        MongoCollection<Document> collection = mongoDatabase.getCollection(collname);

        Document db = new Document("Name","Srijit").append("Age", "22").append("Gender", "Male");
        collection.insertOne(db);

        DeleteResult result = collection.deleteOne(db);
        System.out.println(result.getDeletedCount());
        System.out.println("Document Deleted Succesfully");
    }
}
