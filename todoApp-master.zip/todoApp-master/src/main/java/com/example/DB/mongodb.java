package com.example.DB;

import java.util.ArrayList;
import java.util.List;

import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.result.DeleteResult;
import com.mysql.cj.x.protobuf.MysqlxCrud.Delete;

import org.bson.Document;

public class mongodb {
    public static void main(String[] args) {
        String dbname = "mongotesting";
        String collname = "testing";
        // Create the Mongo Client
        MongoClient mongoClient = new MongoClient("localhost", 27017);
        //System.out.println(mongoClient);
        MongoDatabase mongoDatabase = mongoClient.getDatabase(dbname);
        MongoCollection<Document> collection = mongoDatabase.getCollection(collname);
        //System.out.println(collection);
        Document doc = new Document("Name", "Srijit").append("Age", "22").append("Gender", "Male");
        Document doc1 = new Document("Name", "Barsha").append("Age", "21").append("Gender", "Female");
        Document doc2 = new Document("Name", "Ayush").append("Age", "8").append("Gender", "Male");
        Document doc3 = new Document("Name", "Sanju").append("Age", "18").append("Gender", "Male");
        Document doc4 = new Document("Name", "Subhajit").append("Age", "37").append("Gender", "Male");

        List<Document> doclist = new ArrayList<>();
        doclist.add(doc);
        doclist.add(doc1);
        doclist.add(doc2);
        doclist.add(doc3);

        collection.insertOne(doc4);
        //collection.insertMany(doclist);
        //DeleteResult result = collection.deleteOne(doc);
        //System.out.println(result.getDeletedCount());
        System.out.println("Document Inserted Succesfully"); 
        //System.out.println("Document Deleted Succesfully");   
    } 
}
