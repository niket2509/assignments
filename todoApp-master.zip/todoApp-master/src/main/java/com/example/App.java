package com.example;

import java.sql.*;

import com.mongodb.*;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
